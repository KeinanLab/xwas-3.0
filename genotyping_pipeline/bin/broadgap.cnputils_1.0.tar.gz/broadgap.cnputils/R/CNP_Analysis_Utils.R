# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright 2008 by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

cnp_analysis_utils.hardyWeinberg <- function(aa, ab, bb) {
        observed <- c(aa,ab,bb)
        freq_a = (2*aa+ab) / (2*sum(observed))
        freq_b = (2*bb+ab) / (2*sum(observed))
        expected <- c( freq_a*freq_a*sum(observed), 2*freq_a*freq_b*sum(observed), freq_b*freq_b*sum(observed) )
        chisq <- sum( (observed-expected)^2 / expected )
        #added for monomorphic CNVs
        if (is.na(chisq)) chisq=0
        pchisq(chisq, df=1, lower.tail=FALSE)
}

#calculate the call rate of data given the uncertainty info.
#the data must be less than the threshold to be considered passing call rate.
#returns a vector of CNV names and their call rate.
cnp_analysis_utils.callRate<-function (uncertaintyDF, threshold=0.1) {
   cr<-function (x, t) {
      x<-x[!is.na(x)]
      length(which(x<t))/length(x)  
   }

   r<- apply (uncertaintyDF, 1, cr, threshold)
   return (r)
}


cnp_analysis_utils.basic_allele_freq<-function (genotypeDF) {
  basic<-function (x) {
    x<-as.numeric (x)

    if (all(is.na(x))) return (0)
    x<-x[!is.na(x)]
    z<-table(x)
    majorClass<- as.numeric (names (which (z==max(z))))
    countOtherClasses=length(which (x!=majorClass)) 
    freq=countOtherClasses/length(x)
    return (freq)
  }
  freq<-apply (genotypeDF, 1, basic)
  return (freq)
}

# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright 2008 by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

########################################
# HANDLE IO FOR CNP GENOTYPING PLATFORM
# THIS HANDLES BOTH READING/WRITING FILES.
########################################

###############
# CONSTANTS
###############
TARGET_FILE_CNP_INFO_WIDTH=4
PROFILE_FILE_CNP_INFO_WIDTH=4

#Read in a dataframe that has a column called "cnp_id" that has the cnp ID, and all other columns are sample names.  Each row is the data for one CNP.
cnp_io.readCNPAttribute<-function (filename) {
	a<- read.table(filename, header=T, check.names=F, as.is=T, stringsAsFactors=F, comment.char='?')
	return (a)
}

cnp_io.readCNPAttribute2<-function (filename, ...) {
	read.table(filename, header=T, check.names=F, as.is=T, row.names=1, stringsAsFactors=F, comment.char='?', ...)
}

#Read in a map file, return a data frame with the CEL file name and corresponding sample name and plate name.
cnp_io.read_map<-function (filename) {
   a<- read.table(filename, header=F, check.names=F, as.is=T, stringsAsFactors=F, comment.char="?")
   data.frame(cel=a$V1, sample=a$V2, plate=a$V3)
}

#Turns a profile into an unaltered data frame
cnp_io.readProfileFile<-function (profileFile) read.table(profileFile,header=T, check.names=F, as.is=T, stringsAsFactors=F, comment.char="?")

#Read a bunch of profiles in and concatonate the samples together.
#If there is only one profile in the list, return that data frame.
#All profiles must contain the same set of CNPs to be merged.
cnp_io.readProfiles<-function (profileList) {
	profileDFs<-sapply (profileList, cnp_io.readProfileFile)
	resultMatrix<-matrix()
	
	if (length(profileDFs)==1) return (profileDFs[[1]])
	
	#if the number of profiles > 1, test them to see that they contain the same list of CNPs.
	if (length(profileDFs) >1 && cnp_io.validateProfileList(profileDFs) ) {
		for (i in 1:length(profileDFs)) {
			r<-profileDFs[[i]][,-(1:PROFILE_FILE_CNP_INFO_WIDTH)]
			resultMatrix<-cbind (resultMatrix, r)
		}
	}
	resultMatrix<-cbind(cnp_id=profileDFs[[1]]$cnp_id, resultMatrix)
	return (resultMatrix)
}

cnp_io.readProfileIntensities<-function (profileDF) return (profileDF[,-(1:PROFILE_FILE_CNP_INFO_WIDTH)])

#validate that the profiles have the same CNPs.
cnp_io.validateProfileList<-function (profileDFs, verbose) {
	cnpNameList<-sapply (profileDFs, function (x) x$cnp_id)
	allCNPNames<-unique (as.vector(unlist(cnpNameList)))
	cnpTest<-apply (cnpNameList, 2, function (x) length (intersect(x, allCNPNames)) == length(allCNPNames))  
	idxFailing<-which (cnpTest==F)
	if (length (idxFailing)>0 && verbose) {
		print ("Profiles have different CNPs")
		return (F)
	}
	return (T)
}

cnp_io.readPlateMetaData<-function (plateMetaDataList) {
	plateMD<-list()
	for (i in 1:length(plateMetaDataList)) {
		mdName<-names(plateMetaDataList)[i]
		data<-read.table(plateMetaDataList[[mdName]], header=T, as.is=T)
		plateMD[[mdName]]<-data
	}
	return (plateMD)
}

#read smart probe file
cnp_io.readSmartProbeFile<-function (smartProbeFile) read.table(smartProbeFile, header=T, as.is=T, stringsAsFactors=F)

#read target file
cnp_io.readTargetFile <- function (targetFile)  read.table(targetFile, header=T, check.names=F, as.is=T, stringsAsFactors=F)



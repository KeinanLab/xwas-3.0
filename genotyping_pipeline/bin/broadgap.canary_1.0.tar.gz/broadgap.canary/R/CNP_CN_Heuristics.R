# The Broad Institute
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright 2008 by the
# Broad Institute/Massachusetts Institute of Technology. All rights are
# reserved.

# This software is supplied without any warranty or guaranteed support
# whatsoever. Neither the Broad Institute nor MIT can be responsible for its
# use, misuse, or functionality.

#source ("CNP_IO.R")
#source ("CNP_Utils.R")
#source ("CNP_Analysis_Utils.R")

#Using a matrix of cluster assignments, return the copy number assignments for the cluster assignments.
#the assignment and intensity files do not have to be in frame for either sample name or cnp name.
#assignmentFile <-"Broad6_Result/allData_clusterShifterAssignments.txt"
#intensityFile<-"Broad6_Result/allData_intensities.txt"
#outDir <-"Broad6_Result"
#assignmentFile<-"Affy_6.0_JK_HapMap_Pooled/calls.txt"
#intensityFile<-"Affy_6.0_JK_HapMap_Pooled/allData_intensity.txt"
#outDir<-"Affy_6.0_JK_HapMap_Pooled"

cn_heuristics.callGenotypesByFile<-function (assignmentFile, intensityFile, outDir=NULL, verbose=F) {
	assignmentDF<-cnp_io.readCNPAttribute2(assignmentFile)
	intensityDF<-cnp_io.readCNPAttribute2(intensityFile)
	result<-cn_heuristics.callGenotypesByDF(assignmentDF, intensityDF, outDir, verbose)
	return (result)
}

cn_heuristics.callGenotypesByDF<-function (assignmentDF, intensityDF, outDir=NULL, verbose=F) {
	
	result<-cnpUtils.cloneMatrix(assignmentDF)
	cnpNames<-rownames(assignmentDF)
	
	#align data sets.
	temp<-cnpUtils.alignTwoDataSets(assignmentDF, intensityDF)
	assignmentDF<-temp$data
	intensityDF<-temp$dependant
	
	if (length(temp$missingSamples)>0) print (paste ("assignment matrix had samples that were not in intensity file: ", missingSamples))
	
	for (i in cnpNames) {
		#get the assignment data for one CNP.  Get the matching intensity info by sample name.
		result <-cn_heuristics.callGenotypesOneCNP(assignmentDF, intensityDF, i, result, verbose)
	}	
	
	result<-data.frame(result, check.names=F)
	if (!is.null(outDir)) {
		outFile<-paste(outDir, "/allData_genotypes.txt", sep="")
		r<-data.frame(cbind(cnp_id=rownames(result), result),check.names=F)
		write.table(r, outFile, row.names=F, col.names=T, quote=F)
	}
	return (result)
}

cn_heuristics.callGenotypesOneCNP<-function (assignmentDF, intensityDF, cnpName, result, verbose=F) {
	adjustmentFactor=1.1
	
	print (paste("Calling genotype", cnpName, sep=" "))
		
	#remove NAs from assignments, and corresponding NAs from intensity data.
	idx<-!is.na(assignmentDF[cnpName,])
	assignmentOneCNP <-assignmentDF[cnpName, idx]
	intensityOneCNP<-intensityDF[cnpName,idx]
	
	genotypes<-cn_heuristics.convertToCopyNumber2(assignmentOneCNP, intensityOneCNP, adjustmentFactor, verbose)
	if (!is.null(genotypes)) result[cnpName, colnames(assignmentOneCNP)]<-genotypes
	return (result)
}


test<-function (cnpName) {
	adjustmentFactor=1.1
	idx<-!is.na(assignmentDF[cnpName,])
	assignmentOneCNP <-assignmentDF[cnpName, idx]
	intensityOneCNP<-intensityDF[cnpName,idx]
	assignments<-as.integer(assignmentOneCNP)
	numCenters<-length (unique (assignments))
	intensity<-as.numeric(intensityOneCNP)
	print (paste ("Num centers" , numCenters))
	clusterMeans<-cn_heuristics.clusterMeans(assignments, intensity)
	labelDF<-cn_heuristics.initializeLabels(clusterMeans, maxLabel=4)
	labelDF<-cn_heuristics.deltaTest(labelDF, clusterMeans)
	print (labelDF)
	ci<-cn_heuristics.centerInfo(assignmentOneCNP, intensityOneCNP)
	if (ci$getCount("left")>ci$getCount("right")*adjustmentFactor) print ("left > right")
	if (ci$getCount("right")>ci$getCount("left")* adjustmentFactor) print ("right > left")
	print (paste("largest cluster", which.max(assignmentCounts)))
	hwe<-cn_heuristics.testHWE(assignments)
	print (paste ("Pass HWE", hwe$passing))

}
#################################
# NEW HEURISTICS FOR CN LABELING
#################################

# FOR 1 center - always 2
# DO THE DELTA TEST for anything above 1 cluster

# FOR 2 center (0,1:1,2:2,3)
# 	- assign labels to ascending scores (0,1 gets 10, 1,2: 20, etc)
#	- RUN the delta test 
#	- Left >> right eliminates 1:2 
# 	- right >> left eliminates 0:1, 2:3
#   - pick the highest best scoring label

# FOR 3 center (0,1,2 -> 2:3:4)
#	- assign labels to 10,20,30
#	- run the delta test

#	- run hwe - if it fails HWE and 2 is the biggest cluster then eliminate 0,1,2 and 2,3,4
#   - pick largest score.

# FOR 4 centers (0,1,2,3 : 1,2,3,4: 2,3,4,5)
# 	- assign labels 10,20,30 (?????)
# 	- delta test
#	- if left is largest, fail 1,2,3,4
#	- if right is largest, fail 0,1,2,3
#	- if biggest is not on the end, 2,3,4,5

#The adjustmentFactor is the scaling factor for how much larger one cluster must be over another
#for certaint tests.  For example, the left cluster 1.5 times > right cluster.
cn_heuristics.convertToCopyNumber2<-function (assignmentOneCNP, intensityOneCNP, adjustmentFactor=1.1, verbose=F) {
	assignments<-as.integer(assignmentOneCNP)
	numCenters<-length (unique (assignments))
	intensity<-as.numeric(intensityOneCNP)
	
	#if there are no cluster centers (this entire CNP was NA'd somehow) return NULL.
	if (numCenters==0) return (NULL)
	#if the cluster labels aren't contiguous, return NULL
	if ((max (assignments ) - min(assignments)) >= numCenters) return (NULL)

	temp<-c() #a vector of genotypes that matches the length of the assignments for a CNP.
 	

	#1 center is the simplest example - everything is 2 copy.
	if (numCenters ==1) {
		temp[1:length(assignments)]<-2
		return (temp)
	}
	
	if (numCenters==2) {
		clusterMeans<-cn_heuristics.clusterMeans(assignments, intensity)
		labelDF<-cn_heuristics.initializeLabels(clusterMeans, maxLabel=3)
		labelDF<-cn_heuristics.deltaTest(labelDF, clusterMeans)
		ci<-cn_heuristics.centerInfo(assignmentOneCNP, intensityOneCNP)
		
		
		if (ci$getCount("left")>ci$getCount("right")*adjustmentFactor) {
			labelDF=cn_heuristics.setLabelScore(labelDF, c(1,2), -Inf)
		}
		if (ci$getCount("right")>ci$getCount("left")* adjustmentFactor) {
			labelDF=cn_heuristics.setLabelScore(labelDF, c(0,1), -Inf)
			labelDF=cn_heuristics.setLabelScore(labelDF, c(2,3), -Inf)
		}
		return (cn_heuristics.assignLabels(labelDF, assignments))
		
	}
	
	if (numCenters==3) {
		clusterMeans<-cn_heuristics.clusterMeans(assignments, intensity)
		labelDF<-cn_heuristics.initializeLabels(clusterMeans, maxLabel=4)
		labelDF<-cn_heuristics.deltaTest(labelDF, clusterMeans)
		assignmentCounts<-cn_heuristics.assignmentCounts(assignments)
		
		ci<-cn_heuristics.centerInfo(assignmentOneCNP, intensityOneCNP)
		hwe<-cn_heuristics.testHWE(assignments)
		#If you are center cluster out of HWE with too few hets, don't genotype.
		#This handles >1 cluster being the most frequent one, as long as one of them is the center.
	    if (which.max(assignmentCounts)==2 & hwe$passing==FALSE) {
	    	labelDF=cn_heuristics.setLabelScore(labelDF, c(0,1,2), -Inf)
			labelDF=cn_heuristics.setLabelScore(labelDF, c(2,3,4), -Inf)
		}
		#A possibly useful rule in future.
		#if (which.max(assignmentCounts)!=2 & hwe$passing==FALSE) {
		#	labelDF=cn_heuristics.setLabelScore(labelDF, c(0,1,2), -Inf)
		#	labelDF=cn_heuristics.setLabelScore(labelDF, c(2,3,4), -Inf)
		#	labelDF=cn_heuristics.setLabelScore(labelDF, c(1,2,3), -Inf)
		#}
		
		if (hwe$passing) labelDF=cn_heuristics.setLabelScore(labelDF, c(1,2,3), -Inf)
		
		return (cn_heuristics.assignLabels(labelDF, assignments))
	}
	
	#awaiting new calling.
	if (numCenters==4) {
		clusterMeans<-cn_heuristics.clusterMeans(assignments, intensity)
		labelDF<-cn_heuristics.initializeLabels(clusterMeans, maxLabel=4)
		labelDF<-cn_heuristics.deltaTest(labelDF, clusterMeans)
		ac<-cn_heuristics.assignmentCounts(assignments)
		#make these be majority instead of the largest.
		majorityCluster<-cn_heuristics.getMajorityCluster(assignments)
		
		if (majorityCluster==1)  labelDF=cn_heuristics.setLabelScore(labelDF, c(1,2,3,4), -Inf)
		if (majorityCluster==4) labelDF=cn_heuristics.setLabelScore(labelDF, c(0,1,2,3), -Inf)
		#if (which.max(ac)!=1 && which.max(ac)!=4) labelDF=cn_heuristics.setLabelScore(labelDF, c(2,3,4,5), -Inf)
		 
		if (majorityCluster==2) labelDF=cn_heuristics.setLabelScore(labelDF, c(1,2,3,4), 100)
		if (majorityCluster==3) labelDF=cn_heuristics.setLabelScore(labelDF, c(0,1,2,3), 100)
		
		return (cn_heuristics.assignLabels(labelDF, assignments))
	}
	
	if (numCenters==5) {
		clusterMeans<-cn_heuristics.clusterMeans(assignments, intensity)
		labelDF<-cn_heuristics.initializeLabels(clusterMeans, maxLabel=5)
		labelDF<-cn_heuristics.setLabelScore(labelDF, c(0,1,2,3,4), Inf)
		return (cn_heuristics.assignLabels(labelDF, assignments))
	}
	print (paste("No case for ", numCenters, "for ", rownames(assignmentOneCNP)))
	return (NA)
}


#picks out the best labels from the model, and shifts the assignemnts to match the label.
#if there is no best label, return NULL.
cn_heuristics.assignLabels<-function (labelDF, assignments) {
	uniqueScores<-unique(labelDF$score)
	#if inf is the only score, label NA.
	if (length (setdiff(uniqueScores, -Inf))==0) {
		assignments<-NA 
		return (assignments)
	}
	idx<-which (labelDF$score==max(labelDF$score))
	if (length(idx)>1) print ("PROBLEM")
	bestLabel<-labelDF[idx,]
	if (bestLabel$score==-Inf) return (NULL)
	bestLabel<-bestLabel[-(length(bestLabel))]
	shift<-max(bestLabel)-max(assignments)
	result<-assignments+shift
	return (result)
}

#scores is a list of vector of numeric scores.
cn_heuristics.initializeLabels<-function (clusterMeans, maxLabel=4, scores=NULL) {
	if (length(clusterMeans)==1) return (NULL)

	nrow<-(maxLabel+1) - (length(clusterMeans)-1)
	
	if (is.null(scores)) scores<-10*(1:nrow)
	
	f<-function (startingLabel, size, scores) c(seq(startingLabel, startingLabel+size-1), scores[(startingLabel+1)])
	
	labels<-t(sapply (0:(nrow-1), f, length(clusterMeans), scores))
	result<-data.frame(labels)
	colnames(result)<-c(1:length(clusterMeans), "score")
	return (result)
}

cn_heuristics.getLabelIndex<-function (labelDF, labelList) {
	searchLine<-function (labelLine, labelList) {
		all(sapply (1:length(labelList), function (idx, labelLine) labelList[idx]==labelLine[idx], labelLine))
	}
	
	which (apply (labelDF, 1, searchLine, labelList))
}

cn_heuristics.setLabelScore<-function (labelDF, labelList, score) {
	idx<-cn_heuristics.getLabelIndex(labelDF, labelList)
	labelDF[idx,]$score=labelDF[idx,]$score+score
	return (labelDF)
}

#For any number of labels 
#delta (mean larger - mean smaller).  find the smallest delta
#mean of each cluster should be larger than (i * delta) > 0 (i = label number) 
#Test many labels (5 labels)
#tell you which labels are appropriate.
#if the number of clusterMeans is one, then return NULL
cn_heuristics.deltaTest<-function (labelDF, clusterMeans) {
	if (length(clusterMeans)==1) return (NULL)
	
	#minDelta<-min (diff(clusterMeans))
	#integrate the deltas.
	deltas<-diff(clusterMeans)
			
	testLabel<-function (idx, labelList, clusterMeans, deltas) {
		clusterMeans[idx] > labelList[idx]* deltas[idx]
	}
		
	for (i in 1:dim(labelDF)[1]) {
		l<-labelDF[i,-(dim(labelDF)[2])]
		test<-sapply (1:(length(l)-1), testLabel, l, clusterMeans, deltas)
		if (!all(test)) labelDF[i,]$score=(-Inf)
	}
	
	return (labelDF)
}


#get the means for the cluster labels, starting with the smallest label.
cn_heuristics.clusterMeans<-function (assignments, intensity) {
	uAssigns<-sort (unique(as.integer(assignments)))
	getMeanForAssignment<-function (x, intensity) mean(intensity[which(assignments==x)])
	clusterMeans<-sapply (uAssigns, getMeanForAssignment, intensity) 
	return (clusterMeans)
}

cn_heuristics.assignmentCounts<-function (assignments) {
	uAssigns<-sort (unique(as.integer(assignments)))
	sapply (uAssigns, function (x) length(which(assignments==x)))
}

#returns the major cluster.  If there is no major cluster, return -1
cn_heuristics.getMajorityCluster<-function (assignments, majorityPct=0.3) {
	counts<-cn_heuristics.assignmentCounts(assignments)
	r<-which.max(counts)
	if (counts[r]> majorityPct*length(assignments)) return (r)
	return (-1)
}

cn_heuristics.testHWE<-function (x) {
        x<-x[!is.na(x)]
	#adjust alleles to be 0-2
	d=max(x)-2
	if (d>0) x=x-d
        aa<-length(which(x==0))
        ab<-length(which(x==1))
        bb<-length(which(x==2))
	cnp_analysis_utils.hardyWeinberg(x)
}
